public class Dept{
    private String name ;
}